#ifndef _AKODE_FRAMEDECODER_H
#define _AKODE_FRAMEDECODER_H

#include "decoder.h"

namespace aKode {
/*
    class FrameDecoder : public Decoder
    {
    };*/
    typedef Decoder FrameDecoder;
}

#endif
